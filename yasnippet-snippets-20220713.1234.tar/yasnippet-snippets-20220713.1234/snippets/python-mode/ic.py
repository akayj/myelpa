# -*- mode: snippet -*-
# name: ic
# key: ic
# --
from icecream import ic
ic($1)
